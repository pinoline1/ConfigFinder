package com.configfinder;

/** Minimal JSON writer (no org.json so the core can be unit-tested on a plain JVM). */
final class Json {
    private Json() {}

    static String str(String s) {
        if (s == null) s = "";
        StringBuilder b = new StringBuilder(s.length() + 2).append('"');
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            switch (ch) {
                case '"': b.append("\\\""); break;
                case '\\': b.append("\\\\"); break;
                case '\n': b.append("\\n"); break;
                case '\r': b.append("\\r"); break;
                case '\t': b.append("\\t"); break;
                case ' ': b.append("\\u2028"); break;
                case ' ': b.append("\\u2029"); break;
                default:
                    if (ch < 0x20) b.append(' ');
                    else b.append(ch);
            }
        }
        return b.append('"').toString();
    }

    static String cfg(Cfg c) {
        return "{\"l\":" + str(c.link)
                + ",\"p\":" + str(c.proto)
                + ",\"h\":" + str(c.host)
                + ",\"o\":" + c.port
                + ",\"n\":" + str(c.name)
                + ",\"t\":" + str(c.net)
                + ",\"s\":" + str(c.sec)
                + ",\"f\":" + c.first
                + ",\"g\":" + c.ping
                + ",\"c\":" + c.pop + "}";
    }
}
