package com.configfinder;

/** Switches that only the unit tests flip. Production code never changes them. */
final class Flags {
    /** Allow plain http:// sources (tests only; the app accepts https:// only). */
    static volatile boolean allowHttp = false;
    /** Allow loopback / private addresses (tests only). By default they are skipped so a
     *  config list can never make the phone probe the user's own local network. */
    static volatile boolean allowPrivate = false;

    private Flags() {}
}
