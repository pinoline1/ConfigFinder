package com.configfinder;

import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.util.Collections;

import javax.net.ssl.SNIHostName;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLParameters;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

/**
 * Checks whether a server answers from THIS phone's network.
 *  - TCP connect time is the "ping".
 *  - For TLS / Reality configs a TLS handshake must also succeed. That removes servers that have
 *    the port open but are not really speaking TLS (dead or fake).
 * This proves the server is reachable, not that the proxy password/ID is still valid.
 */
final class Tester {
    static final int TCP_TIMEOUT = 3000;
    static final int TLS_TIMEOUT = 4000;
    private static SSLSocketFactory factory;

    private Tester() {}

    /** Fills c.alive and c.ping. Never throws. */
    static void test(Cfg c) {
        c.alive = false;
        c.ping = -1;
        try {
            InetAddress a = InetAddress.getByName(c.host);
            // A poisoned DNS answer (for example the 10.10.34.x block-page address) is not a real server.
            if (!Flags.allowPrivate && (a.isAnyLocalAddress() || a.isLoopbackAddress()
                    || a.isSiteLocalAddress() || a.isLinkLocalAddress() || a.isMulticastAddress())) {
                return;
            }
            int best = connectOnce(a, c, true);
            if (best < 0) return;
            if (best < 1500) {
                int second = connectOnce(a, c, false);
                if (second >= 0 && second < best) best = second;
            }
            c.ping = Math.max(1, best);
            c.alive = true;
        } catch (Exception ignored) {
            // unresolved host, unreachable, timeout: simply not alive
        }
    }

    private static int connectOnce(InetAddress a, Cfg c, boolean handshake) {
        Socket s = new Socket();
        try {
            long t0 = System.nanoTime();
            s.connect(new InetSocketAddress(a, c.port), TCP_TIMEOUT);
            int ms = (int) ((System.nanoTime() - t0) / 1000000L);
            if (handshake && c.tls() && !tlsHello(s, c)) return -1;
            return ms;
        } catch (Exception e) {
            return -1;
        } finally {
            try {
                s.close();
            } catch (IOException ignored) {
            }
        }
    }

    private static boolean tlsHello(Socket s, Cfg c) {
        try {
            String sni = c.sni.isEmpty() ? c.host : c.sni;
            boolean ip = sni.indexOf(':') >= 0 || sni.matches("[0-9.]+");
            SSLSocket ssl = (SSLSocket) factory().createSocket(s, ip ? c.host : sni, c.port, true);
            ssl.setSoTimeout(TLS_TIMEOUT);
            if (!ip) {
                try {
                    SSLParameters sp = ssl.getSSLParameters();
                    sp.setServerNames(Collections.singletonList(new SNIHostName(sni)));
                    ssl.setSSLParameters(sp);
                } catch (Exception ignored) {
                    // invalid SNI string: continue without it
                }
            }
            ssl.startHandshake();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Trust-all is intentional and safe here: this socket is only a reachability probe. It sends a
     * ClientHello and nothing else, no user data. Reality servers present someone else's
     * certificate on purpose, so normal certificate checking would reject healthy servers.
     */
    private static synchronized SSLSocketFactory factory() throws Exception {
        if (factory == null) {
            TrustManager[] tm = {new X509TrustManager() {
                @Override
                public void checkClientTrusted(X509Certificate[] chain, String authType) {
                }

                @Override
                public void checkServerTrusted(X509Certificate[] chain, String authType) {
                }

                @Override
                public X509Certificate[] getAcceptedIssuers() {
                    return new X509Certificate[0];
                }
            }};
            SSLContext ctx = SSLContext.getInstance("TLS");
            ctx.init(null, tm, new SecureRandom());
            factory = ctx.getSocketFactory();
        }
        return factory;
    }
}
