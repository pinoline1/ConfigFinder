package com.configfinder;

import android.app.job.JobParameters;
import android.app.job.JobService;
import android.content.Context;

/** Runs the refresh in the background, roughly every 3 hours (scheduled by MainActivity). */
public class RefreshJobService extends JobService {

    @Override
    public boolean onStartJob(final JobParameters params) {
        final Context app = getApplicationContext();
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Core.refresh(app, true);
                } finally {
                    jobFinished(params, false);
                }
            }
        }, "refresh-job").start();
        return true;
    }

    @Override
    public boolean onStopJob(JobParameters params) {
        return true; // ask the system to retry later
    }
}
