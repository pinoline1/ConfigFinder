package com.configfinder;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ComponentName;
import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private static final int JOB_ID = 3003;

    private WebView web;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(13, 17, 23));
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);     // the bundled page is still reachable via file:///android_asset
        s.setAllowContentAccess(false);
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return true; // the page never navigates anywhere else
            }
        });
        web.addJavascriptInterface(new Bridge(), "Android");
        web.loadUrl("file:///android_asset/index.html");
        setContentView(web);

        scheduleJob();
        if (System.currentTimeMillis() - Core.updated(this) > Core.INTERVAL_MS) startRefresh();
    }

    /** Every 3 hours, also when the app is closed and after a reboot. */
    private void scheduleJob() {
        try {
            JobScheduler js = (JobScheduler) getSystemService(Context.JOB_SCHEDULER_SERVICE);
            if (js.getPendingJob(JOB_ID) != null) return;
            JobInfo info = new JobInfo.Builder(JOB_ID, new ComponentName(this, RefreshJobService.class))
                    .setPeriodic(Core.INTERVAL_MS)
                    .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                    .setPersisted(true)
                    .build();
            js.schedule(info);
        } catch (Exception ignored) {
            // scheduling is best effort; the app still refreshes whenever it is opened
        }
    }

    private void startRefresh() {
        final Context app = getApplicationContext();
        new Thread(new Runnable() {
            @Override
            public void run() {
                Core.refresh(app, false);
            }
        }, "refresh").start();
    }

    @Override
    public void onBackPressed() {
        // Let the page close its settings sheet first; leave the app only if it did nothing.
        web.evaluateJavascript("(window.goBack ? window.goBack() : false)", new ValueCallback<String>() {
            @Override
            public void onReceiveValue(String value) {
                if (!"true".equals(value)) finish();
            }
        });
    }

    @Override
    protected void onDestroy() {
        if (web != null) {
            web.removeJavascriptInterface("Android");
            web.destroy();
        }
        super.onDestroy();
    }

    /** Methods the page can call. Only our own bundled page is ever loaded in this WebView. */
    public final class Bridge {
        @JavascriptInterface
        public String state() {
            return Core.stateJson(getApplicationContext());
        }

        @JavascriptInterface
        public String configs() {
            return Core.configsJson(getApplicationContext());
        }

        @JavascriptInterface
        public String refresh() {
            if (Refresher.isRunning()) return "busy";
            startRefresh();
            return "ok";
        }

        @JavascriptInterface
        public void copy(final String text) {
            if (text == null || text.length() > 300000) return;
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    cm.setPrimaryClip(ClipData.newPlainText("config", text));
                }
            });
        }

        @JavascriptInterface
        public String sources() {
            StringBuilder sb = new StringBuilder();
            for (String s : Core.sources(getApplicationContext())) sb.append(s).append('\n');
            return sb.toString();
        }

        @JavascriptInterface
        public String saveSources(String text) {
            return Core.saveSources(getApplicationContext(), text);
        }

        @JavascriptInterface
        public String resetSources() {
            Core.resetSources(getApplicationContext());
            return sources();
        }
    }
}
