package com.configfinder;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;

import java.io.File;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Glue between the Android UI and the pure-Java core. */
final class Core {
    static final long INTERVAL_MS = 3L * 60 * 60 * 1000;

    /** Public GitHub lists of free configs. Edit them from the app's settings screen. */
    static final String[] DEFAULT_SOURCES = {
            "https://raw.githubusercontent.com/Epodonios/v2ray-configs/main/All_Configs_Sub.txt",
            "https://raw.githubusercontent.com/barry-far/V2ray-Config/main/All_Configs_Sub.txt",
            "https://raw.githubusercontent.com/ebrasha/free-v2ray-public-list/refs/heads/main/V2Ray-Config-By-EbraSha-All-Type.txt",
            "https://raw.githubusercontent.com/soroushmirzaei/telegram-configs-collector/main/protocols/vless",
            "https://raw.githubusercontent.com/soroushmirzaei/telegram-configs-collector/main/protocols/vmess",
            "https://raw.githubusercontent.com/soroushmirzaei/telegram-configs-collector/main/protocols/trojan",
            "https://raw.githubusercontent.com/soroushmirzaei/telegram-configs-collector/main/protocols/shadowsocks",
            "https://raw.githubusercontent.com/yebekhe/TelegramV2rayCollector/main/sub/normal/vless",
            "https://raw.githubusercontent.com/yebekhe/TelegramV2rayCollector/main/sub/normal/vmess",
            "https://raw.githubusercontent.com/yebekhe/TelegramV2rayCollector/main/sub/normal/trojan",
            "https://raw.githubusercontent.com/iboxz/free-v2ray-collector/main/main/vless",
            "https://raw.githubusercontent.com/iboxz/free-v2ray-collector/main/main/trojan",
            "https://raw.githubusercontent.com/iboxz/free-v2ray-collector/main/main/shadowsocks",
            "https://raw.githubusercontent.com/Mohammadgb0078/IRV2ray/main/vless.txt",
            "https://raw.githubusercontent.com/Mohammadgb0078/IRV2ray/main/vmess.txt",
            "https://raw.githubusercontent.com/Kwinshadow/TelegramV2rayCollector/main/sublinks/mix.txt",
    };

    private Core() {}

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("config_finder", Context.MODE_PRIVATE);
    }

    static List<String> sources(Context c) {
        String s = prefs(c).getString("sources", null);
        List<String> out = new ArrayList<>();
        if (s == null) {
            for (String d : DEFAULT_SOURCES) out.add(d);
            return out;
        }
        for (String line : s.split("\n")) {
            line = line.trim();
            if (!line.isEmpty()) out.add(line);
        }
        return out;
    }

    /** Returns "ok" or an error message. */
    static String saveSources(Context c, String text) {
        Set<String> set = new LinkedHashSet<>();
        if (text != null) {
            for (String line : text.split("\n")) {
                line = line.trim();
                if (line.isEmpty()) continue;
                if (!line.startsWith("https://") || line.length() > 500 || line.indexOf(' ') >= 0) {
                    return "فقط آدرس‌های https:// قبول می‌شه: " + (line.length() > 40 ? line.substring(0, 40) + "…" : line);
                }
                set.add(line);
            }
        }
        if (set.isEmpty()) return "حداقل یک آدرس لازمه";
        if (set.size() > 40) return "حداکثر ۴۰ منبع مجازه";
        StringBuilder sb = new StringBuilder();
        for (String s : set) sb.append(s).append('\n');
        prefs(c).edit().putString("sources", sb.toString()).apply();
        return "ok";
    }

    static void resetSources(Context c) {
        prefs(c).edit().remove("sources").apply();
    }

    static boolean vpnActive(Context c) {
        try {
            ConnectivityManager cm = (ConnectivityManager) c.getSystemService(Context.CONNECTIVITY_SERVICE);
            Network n = cm.getActiveNetwork();
            if (n == null) return false;
            NetworkCapabilities nc = cm.getNetworkCapabilities(n);
            return nc != null && nc.hasTransport(NetworkCapabilities.TRANSPORT_VPN);
        } catch (Exception e) {
            return false;
        }
    }

    static long updated(Context c) {
        return Store.num(Store.meta(c.getFilesDir()).get("updated"), 0);
    }

    /** Runs a refresh now (blocking). From the background job it is skipped while a VPN is on. */
    static boolean refresh(Context c, boolean fromJob) {
        boolean vpn = vpnActive(c);
        if (fromJob && vpn) return false;   // pings through a VPN would be meaningless
        File dir = c.getFilesDir();
        return Refresher.run(dir, sources(c), vpn);
    }

    static String stateJson(Context c) {
        Map<String, String> m = Store.meta(c.getFilesDir());
        StringBuilder sb = new StringBuilder("{");
        sb.append("\"running\":").append(Refresher.isRunning());
        sb.append(",\"stage\":").append(Json.str(Refresher.stage));
        sb.append(",\"done\":").append(Refresher.done);
        sb.append(",\"total\":").append(Refresher.total);
        sb.append(",\"updated\":").append(Store.num(m.get("updated"), 0));
        sb.append(",\"baseline\":").append(Store.num(m.get("baseline"), 0));
        sb.append(",\"found\":").append(Store.num(m.get("found"), 0));
        sb.append(",\"tested\":").append(Store.num(m.get("tested"), 0));
        sb.append(",\"alive\":").append(Store.num(m.get("alive"), 0));
        sb.append(",\"srcOk\":").append(Store.num(m.get("srcOk"), 0));
        sb.append(",\"srcTotal\":").append(Store.num(m.get("srcTotal"), 0));
        sb.append(",\"lastVpn\":").append("1".equals(m.get("lastVpn")));
        sb.append(",\"vpn\":").append(vpnActive(c));
        sb.append(",\"error\":").append(Json.str(m.get("error")));
        return sb.append('}').toString();
    }

    static String configsJson(Context c) {
        List<Cfg> list = Store.load(c.getFilesDir());
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < list.size(); i++) {
            if (i > 0) sb.append(',');
            sb.append(Json.cfg(list.get(i)));
        }
        return sb.append(']').toString();
    }
}
