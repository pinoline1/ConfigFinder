package com.configfinder;

import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Finds vmess / vless / trojan / ss links in a text and extracts host, port and details. */
final class Parser {
    private static final Pattern LINK =
            Pattern.compile("(?i)\\b(?:vmess|vless|trojan|ss)://[^\\s\"'<>\\\\]+");
    private static final Pattern IPV4 =
            Pattern.compile("^(\\d{1,3})\\.(\\d{1,3})\\.(\\d{1,3})\\.(\\d{1,3})$");
    private static final Pattern HOST_OK = Pattern.compile("^[A-Za-z0-9._:\\-]{1,253}$");

    private Parser() {}

    /** All valid configs found in the text (the text may itself be base64 encoded). */
    static List<Cfg> extract(String text) {
        List<Cfg> out = new ArrayList<>();
        if (text == null || text.isEmpty()) return out;
        Matcher m = LINK.matcher(maybeDecode(text));
        while (m.find()) {
            Cfg c = parse(m.group());
            if (c != null) out.add(c);
        }
        return out;
    }

    /** Subscription files are often one big base64 blob; decode it when there are no links in it. */
    static String maybeDecode(String text) {
        if (text.contains("://")) return text;
        String d = b64(text.trim());
        return (d != null && d.contains("://")) ? d : text;
    }

    static Cfg parse(String link) {
        try {
            int i = link.indexOf("://");
            if (i <= 0) return null;
            String proto = link.substring(0, i).toLowerCase(Locale.ROOT);
            String rest = link.substring(i + 3);
            String frag = "";
            int h = rest.indexOf('#');
            if (h >= 0) {
                frag = urlDecode(rest.substring(h + 1));
                rest = rest.substring(0, h);
            }
            if (rest.isEmpty()) return null;

            Cfg c = new Cfg();
            c.proto = proto;
            c.link = link;
            boolean ok;
            if (proto.equals("vmess")) ok = vmess(c, rest, frag);
            else if (proto.equals("ss")) ok = ss(c, rest, frag);
            else ok = uri(c, rest, frag);
            if (!ok) return null;

            c.host = c.host.trim().toLowerCase(Locale.ROOT);
            if (!HOST_OK.matcher(c.host).matches()) return null;
            if (!Flags.allowPrivate && isPrivate(c.host)) return null;
            c.name = clean(c.name);
            if (c.name.isEmpty()) c.name = proto.toUpperCase(Locale.ROOT) + " " + c.host;
            return c;
        } catch (Exception e) {
            return null;
        }
    }

    // ---------- protocols ----------

    private static boolean vmess(Cfg c, String payload, String frag) {
        String d = b64(payload);
        if (d == null || d.indexOf('{') < 0) return false;
        String add = js(d, "add");
        String id = js(d, "id");
        if (add.isEmpty() || id.isEmpty()) return false;
        c.host = add;
        c.port = port(js(d, "port"));
        if (c.port < 0) return false;
        c.net = def(js(d, "net"), "tcp");
        c.sec = js(d, "tls").equalsIgnoreCase("tls") ? "tls" : "none";
        String hostHdr = firstItem(js(d, "host"));
        String sni = js(d, "sni");
        c.sni = !sni.isEmpty() ? sni : hostHdr;
        String ps = js(d, "ps");
        c.name = ps.isEmpty() ? frag : ps;
        c.key = "vmess|" + c.host + "|" + c.port + "|" + id + "|" + c.net + "|"
                + js(d, "path") + "|" + hostHdr + "|" + c.sec;
        return true;
    }

    /** vless:// and trojan:// */
    private static boolean uri(Cfg c, String rest, String frag) {
        String authority = rest;
        String query = "";
        int q = rest.indexOf('?');
        if (q >= 0) {
            authority = rest.substring(0, q);
            query = rest.substring(q + 1);
        }
        int slash = authority.indexOf('/');
        if (slash >= 0) authority = authority.substring(0, slash);
        int at = authority.lastIndexOf('@');
        if (at <= 0) return false;
        if (!hostPort(c, authority.substring(at + 1))) return false;

        Map<String, String> p = params(query);
        c.net = def(p.get("type"), "tcp");
        String sec = p.get("security");
        if (sec == null || sec.isEmpty()) sec = c.proto.equals("trojan") ? "tls" : "none";
        c.sec = sec.toLowerCase(Locale.ROOT);
        String sni = p.get("sni");
        if (sni == null || sni.isEmpty()) sni = p.get("peer");
        if (sni == null || sni.isEmpty()) sni = p.get("host");
        c.sni = sni == null ? "" : sni.trim();
        c.name = frag;
        c.key = c.proto + "://" + rest;
        return true;
    }

    /** ss://BASE64(method:pass@host:port)  or  ss://BASE64(method:pass)@host:port */
    private static boolean ss(Cfg c, String rest, String frag) {
        String body = rest;
        int q = body.indexOf('?');
        if (q >= 0) body = body.substring(0, q);
        while (body.endsWith("/")) body = body.substring(0, body.length() - 1);
        String hp;
        int at = body.lastIndexOf('@');
        if (at >= 0) {
            hp = body.substring(at + 1);
        } else {
            String d = b64(body);
            if (d == null) return false;
            int a2 = d.lastIndexOf('@');
            if (a2 < 0) return false;
            hp = d.substring(a2 + 1);
        }
        if (!hostPort(c, hp)) return false;
        c.net = "tcp";
        c.sec = "none";
        c.name = frag;
        c.key = "ss://" + rest;
        return true;
    }

    // ---------- helpers ----------

    private static boolean hostPort(Cfg c, String hp) {
        hp = hp.trim();
        String host;
        String ps;
        if (hp.startsWith("[")) {
            int e = hp.indexOf(']');
            if (e < 0 || e + 1 >= hp.length() || hp.charAt(e + 1) != ':') return false;
            host = hp.substring(1, e);
            ps = hp.substring(e + 2);
        } else {
            int col = hp.lastIndexOf(':');
            if (col <= 0) return false;
            host = hp.substring(0, col);
            ps = hp.substring(col + 1);
        }
        int port = port(ps);
        if (port < 0 || host.isEmpty()) return false;
        c.host = host;
        c.port = port;
        return true;
    }

    static int port(String s) {
        try {
            int p = Integer.parseInt(s.trim());
            return (p >= 1 && p <= 65535) ? p : -1;
        } catch (Exception e) {
            return -1;
        }
    }

    /** True for addresses that are never a real public proxy (and must not be probed). */
    static boolean isPrivate(String host) {
        if (host.equals("localhost") || host.endsWith(".local") || host.endsWith(".localhost")) return true;
        Matcher m = IPV4.matcher(host);
        if (m.matches()) {
            int a = Integer.parseInt(m.group(1));
            int b = Integer.parseInt(m.group(2));
            if (a > 255 || b > 255 || Integer.parseInt(m.group(3)) > 255 || Integer.parseInt(m.group(4)) > 255) return true;
            return a == 0 || a == 10 || a == 127 || a >= 224
                    || (a == 169 && b == 254)
                    || (a == 192 && b == 168)
                    || (a == 172 && b >= 16 && b <= 31)
                    || (a == 100 && b >= 64 && b <= 127);
        }
        if (host.indexOf(':') >= 0) {
            return host.equals("::") || host.equals("::1") || host.startsWith("fe80")
                    || host.startsWith("fc") || host.startsWith("fd");
        }
        return false;
    }

    static String b64(String s) {
        try {
            if (s.indexOf('%') >= 0) s = urlDecode(s);
            String t = s.replace('-', '+').replace('_', '/');
            byte[] b = Base64.getMimeDecoder().decode(t);
            return new String(b, StandardCharsets.UTF_8);
        } catch (IllegalArgumentException e) {
            return null;
        }
    }

    static String urlDecode(String s) {
        try {
            return URLDecoder.decode(s.replace("+", "%2B"), "UTF-8");
        } catch (Exception e) {
            return s;
        }
    }

    private static Map<String, String> params(String query) {
        Map<String, String> map = new HashMap<>();
        if (query == null || query.isEmpty()) return map;
        for (String pair : query.split("&")) {
            int eq = pair.indexOf('=');
            if (eq <= 0) continue;
            map.put(pair.substring(0, eq).toLowerCase(Locale.ROOT), urlDecode(pair.substring(eq + 1)));
        }
        return map;
    }

    /** Reads a string or number field out of a flat JSON object (enough for a vmess link). */
    private static String js(String json, String field) {
        Matcher m = Pattern.compile("\"" + Pattern.quote(field)
                + "\"\\s*:\\s*(?:\"((?:[^\"\\\\]|\\\\.)*)\"|(-?\\d+))").matcher(json);
        if (!m.find()) return "";
        String v = m.group(1) != null ? unescape(m.group(1)) : m.group(2);
        return v == null ? "" : v.trim();
    }

    private static String unescape(String s) {
        if (s.indexOf('\\') < 0) return s;
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (ch != '\\' || i + 1 >= s.length()) {
                b.append(ch);
                continue;
            }
            char n = s.charAt(++i);
            switch (n) {
                case 'n': b.append(' '); break;
                case 't': b.append(' '); break;
                case 'r': break;
                case 'u':
                    if (i + 4 < s.length()) {
                        try {
                            b.append((char) Integer.parseInt(s.substring(i + 1, i + 5), 16));
                            i += 4;
                        } catch (NumberFormatException e) {
                            b.append('u');
                        }
                    }
                    break;
                default: b.append(n);
            }
        }
        return b.toString();
    }

    private static String def(String v, String d) {
        return (v == null || v.trim().isEmpty()) ? d : v.trim().toLowerCase(Locale.ROOT);
    }

    private static String firstItem(String v) {
        int i = v.indexOf(',');
        return (i >= 0 ? v.substring(0, i) : v).trim();
    }

    private static String clean(String s) {
        if (s == null) return "";
        s = s.replaceAll("[\\p{Cc}\\s]+", " ").trim();
        if (s.length() > 60) {
            int end = 60;
            if (Character.isHighSurrogate(s.charAt(end - 1))) end--;
            s = s.substring(0, end);
        }
        return s;
    }
}
