package com.configfinder;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

/** One full refresh: download sources, parse, test from this phone, keep the alive ones. */
final class Refresher {
    static final int MAX_TEST = 2500;           // configs tested per run
    static final int THREADS = 64;
    static final int MAX_BYTES = 6 * 1024 * 1024; // per source file
    static final int MAX_PER_SOURCE = 20000;
    static final int MAX_TOTAL = 60000;

    private static final AtomicBoolean RUNNING = new AtomicBoolean(false);
    static volatile String stage = "";          // "fetch" | "test" | ""
    static volatile int done;
    static volatile int total;

    private Refresher() {}

    static boolean isRunning() {
        return RUNNING.get();
    }

    /** Returns false if a refresh is already running. */
    static boolean run(File dir, List<String> sources, boolean vpn) {
        if (!RUNNING.compareAndSet(false, true)) return false;
        done = 0;
        total = 0;
        stage = "fetch";
        try {
            work(dir, sources, vpn);
        } catch (Throwable t) {
            fail(dir, "خطای غیرمنتظره: " + t.getClass().getSimpleName());
        } finally {
            stage = "";
            RUNNING.set(false);
        }
        return true;
    }

    private static void work(File dir, List<String> sources, boolean vpn) throws Exception {
        long now = System.currentTimeMillis();

        // ---- 1) download and parse every source ----
        total = sources.size();
        final AtomicInteger fetched = new AtomicInteger();
        ExecutorService fetchPool = pool(6);
        List<Future<List<Cfg>>> futures = new ArrayList<>();
        for (final String u : sources) {
            futures.add(fetchPool.submit(new Callable<List<Cfg>>() {
                @Override
                public List<Cfg> call() {
                    try {
                        return fetch(u);
                    } finally {
                        done = fetched.incrementAndGet();
                    }
                }
            }));
        }

        Map<String, Cfg> all = new LinkedHashMap<>();
        Map<String, Set<String>> groupSeen = new java.util.HashMap<>();
        int srcOk = 0;
        for (int i = 0; i < futures.size(); i++) {
            List<Cfg> list;
            try {
                list = futures.get(i).get(90, TimeUnit.SECONDS);
            } catch (Exception e) {
                list = null;
            }
            if (list == null) continue;
            srcOk++;
            String g = group(sources.get(i));
            Set<String> seen = groupSeen.get(g);
            if (seen == null) {
                seen = new HashSet<>();
                groupSeen.put(g, seen);
            }
            for (Cfg c : list) {
                if (!seen.add(c.key)) continue;     // count each repo once per config
                Cfg ex = all.get(c.key);
                if (ex == null) {
                    if (all.size() < MAX_TOTAL) all.put(c.key, c);
                } else {
                    ex.pop++;
                }
            }
        }
        fetchPool.shutdownNow();

        if (all.isEmpty()) {
            fail(dir, "هیچ منبعی در دسترس نبود. اینترنت و دسترسی به گیت‌هاب رو چک کن.");
            return;
        }

        // ---- 2) choose what to test: most popular first, then ones that worked last time ----
        final Map<String, Cfg> prev = new java.util.HashMap<>();
        for (Cfg p : Store.load(dir)) prev.put(p.key, p);

        List<Cfg> cands = new ArrayList<>(all.values());
        Collections.shuffle(cands, new Random());
        Collections.sort(cands, new Comparator<Cfg>() {
            @Override
            public int compare(Cfg a, Cfg b) {
                if (a.pop != b.pop) return b.pop - a.pop;
                boolean pa = prev.containsKey(a.key);
                boolean pb = prev.containsKey(b.key);
                if (pa != pb) return pa ? -1 : 1;
                return 0;
            }
        });
        if (cands.size() > MAX_TEST) cands = new ArrayList<>(cands.subList(0, MAX_TEST));

        // ---- 3) test them from this phone's own network ----
        stage = "test";
        total = cands.size();
        done = 0;
        final AtomicInteger tested = new AtomicInteger();
        ExecutorService testPool = pool(THREADS);
        for (final Cfg c : cands) {
            testPool.execute(new Runnable() {
                @Override
                public void run() {
                    try {
                        Tester.test(c);
                    } finally {
                        done = tested.incrementAndGet();
                    }
                }
            });
        }
        testPool.shutdown();
        if (!testPool.awaitTermination(300, TimeUnit.SECONDS)) testPool.shutdownNow();

        // ---- 4) keep the alive ones ----
        List<Cfg> alive = new ArrayList<>();
        for (Cfg c : cands) {
            if (!c.alive) continue;
            Cfg p = prev.get(c.key);
            c.first = (p != null && p.first > 0) ? p.first : now;
            c.lastAlive = now;
            alive.add(c);
        }
        Collections.sort(alive, new Comparator<Cfg>() {
            @Override
            public int compare(Cfg a, Cfg b) {
                return a.ping - b.ping;
            }
        });

        Map<String, String> meta = Store.meta(dir);
        // Nothing alive out of many tested usually means the phone is offline or blocked right now.
        // Keep the previous list instead of wiping it.
        if (alive.isEmpty() && cands.size() >= 30) {
            meta.put("error", "هیچ کانفیگ سالمی پیدا نشد. شاید اینترنت قطع یا محدود بود؛ لیست قبلی حفظ شد.");
            meta.put("lastTry", String.valueOf(now));
            Store.saveMeta(dir, meta);
            return;
        }

        Store.save(dir, alive);
        if (!meta.containsKey("baseline")) meta.put("baseline", String.valueOf(now));
        meta.put("updated", String.valueOf(now));
        meta.put("found", String.valueOf(all.size()));
        meta.put("tested", String.valueOf(cands.size()));
        meta.put("alive", String.valueOf(alive.size()));
        meta.put("srcOk", String.valueOf(srcOk));
        meta.put("srcTotal", String.valueOf(sources.size()));
        meta.put("lastVpn", vpn ? "1" : "0");
        meta.put("error", "");
        Store.saveMeta(dir, meta);
    }

    private static void fail(File dir, String msg) {
        Map<String, String> meta = Store.meta(dir);
        meta.put("error", msg);
        meta.put("lastTry", String.valueOf(System.currentTimeMillis()));
        Store.saveMeta(dir, meta);
    }

    /** Downloads one source and parses it. Returns null when the download failed. */
    static List<Cfg> fetch(String url) {
        HttpURLConnection h = null;
        try {
            if (!(url.startsWith("https://") || (Flags.allowHttp && url.startsWith("http://")))) return null;
            h = (HttpURLConnection) new URL(url).openConnection();
            h.setConnectTimeout(12000);
            h.setReadTimeout(25000);
            h.setInstanceFollowRedirects(true);
            h.setRequestProperty("User-Agent", "ConfigFinder/1.0");
            if (h.getResponseCode() != 200) return null;
            InputStream in = h.getInputStream();
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[16384];
            int n;
            while ((n = in.read(buf)) != -1) {
                out.write(buf, 0, n);
                if (out.size() >= MAX_BYTES) break;
            }
            List<Cfg> list = Parser.extract(new String(out.toByteArray(), StandardCharsets.UTF_8));
            if (list.size() > MAX_PER_SOURCE) list = new ArrayList<>(list.subList(0, MAX_PER_SOURCE));
            return list;
        } catch (Exception e) {
            return null;
        } finally {
            if (h != null) h.disconnect();
        }
    }

    /** Files of the same GitHub repo count as ONE source for popularity. */
    static String group(String url) {
        String p = "https://raw.githubusercontent.com/";
        if (url.startsWith(p)) {
            String[] seg = url.substring(p.length()).split("/");
            if (seg.length >= 2) return (seg[0] + "/" + seg[1]).toLowerCase();
        }
        return url;
    }

    private static ExecutorService pool(int n) {
        return Executors.newFixedThreadPool(n, new java.util.concurrent.ThreadFactory() {
            @Override
            public Thread newThread(Runnable r) {
                Thread t = new Thread(r);
                t.setDaemon(true);
                return t;
            }
        });
    }
}
