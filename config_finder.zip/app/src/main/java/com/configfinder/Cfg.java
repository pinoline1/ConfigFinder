package com.configfinder;

/** One proxy config (vmess / vless / trojan / ss) plus the result of its latest test. */
final class Cfg {
    String key = "";     // unique identity (link without the display name)
    String link = "";    // the original share link, copied as-is
    String proto = "";   // vmess | vless | trojan | ss
    String host = "";
    String name = "";
    String net = "";     // transport: tcp / ws / grpc ...
    String sec = "";     // security: tls / reality / none
    String sni = "";
    int port;
    long first;          // when we first saw it alive
    long lastAlive;
    int ping = -1;       // TCP connect time in ms
    int pop = 1;         // number of independent sources (repos) that list it
    boolean alive;

    boolean tls() {
        return sec.equals("tls") || sec.equals("reality") || sec.equals("xtls");
    }
}
