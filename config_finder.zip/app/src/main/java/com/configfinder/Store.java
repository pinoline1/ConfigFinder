package com.configfinder;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Plain-text storage: configs.tsv (the alive list) and meta.txt (status of the last run). */
final class Store {
    private static final Object LOCK = new Object();

    private Store() {}

    static List<Cfg> load(File dir) {
        synchronized (LOCK) {
            List<Cfg> out = new ArrayList<>();
            File f = new File(dir, "configs.tsv");
            if (!f.exists()) return out;
            try (BufferedReader r = new BufferedReader(
                    new InputStreamReader(new FileInputStream(f), StandardCharsets.UTF_8))) {
                String line;
                while ((line = r.readLine()) != null) {
                    String[] p = line.split("\t", -1);
                    if (p.length < 13) continue;
                    Cfg c = new Cfg();
                    c.key = p[0];
                    c.link = p[1];
                    c.proto = p[2];
                    c.host = p[3];
                    c.port = (int) num(p[4], 0);
                    c.name = p[5];
                    c.net = p[6];
                    c.sec = p[7];
                    c.sni = p[8];
                    c.first = num(p[9], 0);
                    c.ping = (int) num(p[10], -1);
                    c.pop = (int) num(p[11], 1);
                    c.lastAlive = num(p[12], 0);
                    c.alive = true;
                    if (!c.key.isEmpty() && !c.link.isEmpty()) out.add(c);
                }
            } catch (IOException ignored) {
            }
            return out;
        }
    }

    static void save(File dir, List<Cfg> list) {
        StringBuilder sb = new StringBuilder();
        for (Cfg c : list) {
            sb.append(f(c.key)).append('\t').append(f(c.link)).append('\t').append(f(c.proto)).append('\t')
                    .append(f(c.host)).append('\t').append(c.port).append('\t').append(f(c.name)).append('\t')
                    .append(f(c.net)).append('\t').append(f(c.sec)).append('\t').append(f(c.sni)).append('\t')
                    .append(c.first).append('\t').append(c.ping).append('\t').append(c.pop).append('\t')
                    .append(c.lastAlive).append('\n');
        }
        write(new File(dir, "configs.tsv"), sb.toString());
    }

    static Map<String, String> meta(File dir) {
        synchronized (LOCK) {
            Map<String, String> m = new LinkedHashMap<>();
            File f = new File(dir, "meta.txt");
            if (!f.exists()) return m;
            try (BufferedReader r = new BufferedReader(
                    new InputStreamReader(new FileInputStream(f), StandardCharsets.UTF_8))) {
                String line;
                while ((line = r.readLine()) != null) {
                    int eq = line.indexOf('=');
                    if (eq > 0) m.put(line.substring(0, eq), line.substring(eq + 1));
                }
            } catch (IOException ignored) {
            }
            return m;
        }
    }

    static void saveMeta(File dir, Map<String, String> m) {
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, String> e : m.entrySet()) {
            sb.append(e.getKey()).append('=').append(f(e.getValue())).append('\n');
        }
        write(new File(dir, "meta.txt"), sb.toString());
    }

    static long num(String s, long def) {
        try {
            return Long.parseLong(s.trim());
        } catch (Exception e) {
            return def;
        }
    }

    private static String f(String s) {
        return s == null ? "" : s.replace('\t', ' ').replace('\n', ' ').replace('\r', ' ');
    }

    /** Write to a temp file, then rename, so a crash never leaves a half-written file. */
    private static void write(File target, String text) {
        synchronized (LOCK) {
            File tmp = new File(target.getPath() + ".tmp");
            try (Writer w = new OutputStreamWriter(new FileOutputStream(tmp), StandardCharsets.UTF_8)) {
                w.write(text);
            } catch (IOException e) {
                return;
            }
            if (!tmp.renameTo(target)) {
                target.delete();
                tmp.renameTo(target);
            }
        }
    }
}
